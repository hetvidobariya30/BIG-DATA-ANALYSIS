# Databricks notebook source
# MAGIC %md
# MAGIC ###Data Reading

# COMMAND ----------

# DBTITLE 1,Data Reading
df = spark.read.format('csv').option('inferSchema', True).option('header', True).load('/Volumes/workspace/default/instagram_usage_lifestyle')

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ###DDL Schema

# COMMAND ----------

my_ddl_schema = """
user_id integer,
app_name string,
age string,
gender string,
country string,
urban_rural string,
income_level string,
employment_status string,
education_level string,
relationship_status string,
has_children string,
exercise_hours_per_week double,
sleep_hours_per_night double,
diet_quality string,
smoking string,
alcohol_frequency string,
perceived_stress_score integer,
self_reported_happiness integer,
body_mass_index double,
blood_pressure_systolic integer,
blood_pressure_diastolic integer,
daily_steps_count integer,
weekly_work_hours double,
hobbies_count integer,
social_events_per_month integer,
books_read_per_year integer,
volunteer_hours_per_month double,
travel_frequency_per_year integer,
      """


# COMMAND ----------

# DBTITLE 1,Cell 7
df = spark.read.format('csv').option('my_ddl_schema',True).option('header', True).load('/Volumes/workspace/default/instagram_usage_lifestyle')

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Select

# COMMAND ----------

df.display()

# COMMAND ----------

# DBTITLE 1,Untitled
df.select('user_id','app_name','age').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Alias

# COMMAND ----------

# DBTITLE 1,Untitled
from pyspark.sql.functions import *
df.select(col('user_id')).alias('Id_number').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filter

# COMMAND ----------

df.filter(col('country') == 'India').display()

# COMMAND ----------

df.filter((col('country')=='India') & (col('gender')=='Female') & (col('age')<20)).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### With column Reanamed

# COMMAND ----------

df.withColumnRenamed("age","User_age").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### withColumn

# COMMAND ----------

df.withColumn('flag',lit('New')).display()

# COMMAND ----------

df.withColumn('multiply',(col('age'))*(col('exercise_hours_per_week'))).display()

# COMMAND ----------

df.withColumn('gender',regexp_replace(col('gender'),'Male','M'))\
    .withColumn('gender',regexp_replace(col('gender'),'Female','F')).display()
    

# COMMAND ----------

# MAGIC %md
# MAGIC ### TypeCastung

# COMMAND ----------

df= df.withColumn('age',col('age').cast(StringType()))

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Sorting

# COMMAND ----------

from pyspark.sql.functions import *
df.sort(col('age').asc()).display()

# COMMAND ----------

# DBTITLE 1,Cell 29
from pyspark.sql.functions import *


# COMMAND ----------

# DBTITLE 1,Untitled
df.sort(['age','sleep_hours_per_night'], ascending = [0,1]).display() 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Limit

# COMMAND ----------

df.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Drop
# MAGIC
# MAGIC

# COMMAND ----------

df.drop('urban_rural').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Drop_Duplicates

# COMMAND ----------

df.dropDuplicates().display()

# COMMAND ----------

df.dropDuplicates(subset = ['country']).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### String Function

# COMMAND ----------

df.select(initcap(col('relationship_status'))).display()

# COMMAND ----------

df.select(upper('relationship_status')).display()

# COMMAND ----------

df.select(lower('relationship_status')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date Function

# COMMAND ----------

# DBTITLE 1,Untitled
df = df.withColumn('curr_date',current_date())
df.display() 

# COMMAND ----------

df=df.withColumn('week_after',date_add('curr_date',7))
df.display()

# COMMAND ----------

df=df.withColumn('dateDiff',datediff('week_after','curr_date'))
df.display()

# COMMAND ----------

df=df.withColumn('curr_date',date_format('curr_date','dd-MM-yyyy'))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Handling Null 

# COMMAND ----------

df.dropna("all").display()